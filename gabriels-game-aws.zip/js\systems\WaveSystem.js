class WaveSystem extends System {
    constructor() {
        super();
        this.currentWave = 0;
        this.waves = this.generateWaves();
        this.spawnTimer = 0;
        this.spawnInterval = 1000;
        this.enemiesInWave = 0;
        this.enemiesSpawned = 0;
        this.enemiesAlive = 0;
        this.waveActive = false;
        this.waveComplete = false;
        this.waveReward = 0;
        this.spawnPosition = { x: 50, y: 200 };
        this.combatEvents = [];
        
        // System dependencies
        this.pathfindingSystem = null;
        this.renderSystem = null;
        this.combatSystem = null;
    }

    setDependencies(dependencies) {
        try {
            console.log('Setting WaveSystem dependencies...');
            this.pathfindingSystem = dependencies.pathfindingSystem;
            this.renderSystem = dependencies.renderSystem;
            this.combatSystem = dependencies.combatSystem;
            this.gameEngine = dependencies.gameEngine; // Add game engine reference
            console.log('WaveSystem dependencies set successfully');
        } catch (error) {
            console.error('Failed to set WaveSystem dependencies:', error);
            throw new Error(`WaveSystem dependency setup failed: ${error.message}`);
        }
    }

    generateWaves() {
        return [
            // Wave 1
            {
                enemies: [
                    { type: 'BASIC', count: 5, spawnDelay: 1000 },
                    { type: 'FAST', count: 3, spawnDelay: 800 }
                ],
                reward: 100,
                description: 'First wave - Basic enemies'
            },
            // Wave 2
            {
                enemies: [
                    { type: 'BASIC', count: 8, spawnDelay: 900 },
                    { type: 'FAST', count: 5, spawnDelay: 700 },
                    { type: 'TANK', count: 2, spawnDelay: 1500 }
                ],
                reward: 150,
                description: 'Second wave - Mixed enemies'
            },
            // Wave 3
            {
                enemies: [
                    { type: 'BASIC', count: 10, spawnDelay: 800 },
                    { type: 'FAST', count: 8, spawnDelay: 600 },
                    { type: 'TANK', count: 3, spawnDelay: 1200 },
                    { type: 'FLYING', count: 4, spawnDelay: 1000 }
                ],
                reward: 200,
                description: 'Third wave - All enemy types'
            },
            // Wave 4
            {
                enemies: [
                    { type: 'BASIC', count: 15, spawnDelay: 700 },
                    { type: 'FAST', count: 12, spawnDelay: 500 },
                    { type: 'TANK', count: 5, spawnDelay: 1000 },
                    { type: 'FLYING', count: 6, spawnDelay: 800 }
                ],
                reward: 250,
                description: 'Fourth wave - Large numbers'
            },
            // Wave 5 (Boss wave)
            {
                enemies: [
                    { type: 'TANK', count: 10, spawnDelay: 2000 },
                    { type: 'FLYING', count: 8, spawnDelay: 1500 }
                ],
                reward: 300,
                description: 'Boss wave - Elite enemies'
            }
        ];
    }

    startWave() {
        console.log(`Starting wave ${this.currentWave + 1} of ${this.waves.length}`);
        
        if (this.currentWave >= this.waves.length) {
            // All waves completed
            this.combatEvents.push({
                type: 'all_waves_complete'
            });
            return false;
        }

        const wave = this.waves[this.currentWave];
        this.waveActive = true;
        this.waveComplete = false;
        this.enemiesInWave = 0;
        this.enemiesSpawned = 0;
        this.enemiesAlive = 0;
        this.waveReward = wave.reward;
        this.spawnTimer = 0;

        // Calculate total enemies in wave and create spawn queue
        this.spawnQueue = [];
        wave.enemies.forEach(enemyGroup => {
            for (let i = 0; i < enemyGroup.count; i++) {
                this.spawnQueue.push({
                    type: enemyGroup.type,
                    spawnDelay: enemyGroup.spawnDelay
                });
            }
            this.enemiesInWave += enemyGroup.count;
        });

        console.log(`Wave ${this.currentWave + 1} started with ${this.enemiesInWave} enemies in queue`);

        this.combatEvents.push({
            type: 'wave_started',
            wave: this.currentWave + 1,
            description: wave.description
        });

        this.currentWave++; // Increment wave counter
        return true;
    }

    update(deltaTime) {
        if (this.waveActive && !this.waveComplete) {
            this.spawnTimer += deltaTime;
            this.updateSpawning(deltaTime);
            this.updateWaveStatus();
            
            // Debug logging every 5 seconds
            if (this.spawnTimer % 5000 < deltaTime) {
                console.log(`WaveSystem Debug - Wave: ${this.currentWave}, Spawned: ${this.enemiesSpawned}/${this.enemiesInWave}, Alive: ${this.enemiesAlive}, Active: ${this.waveActive}`);
            }
        }
    }

    updateSpawning(deltaTime) {
        if (this.enemiesSpawned >= this.enemiesInWave || !this.spawnQueue || this.spawnQueue.length === 0) {
            return;
        }

        const nextEnemy = this.spawnQueue[0];
        const spawnInterval = nextEnemy.spawnDelay || 1000; // Use individual spawn delay

        if (this.spawnTimer >= spawnInterval) {
            this.spawnEnemy(nextEnemy.type);
            this.spawnQueue.shift(); // Remove from queue
            this.spawnTimer = 0;
        }
    }

    // Removed complex spawning methods - now using simple queue-based approach

    spawnEnemy(enemyType) {
        const enemyData = EnemyComponent.TYPES[enemyType];
        if (!enemyData) return null;

        const entity = new Entity();
        entity.addComponent(new PositionComponent(this.spawnPosition.x, this.spawnPosition.y));
        
        const enemy = new EnemyComponent(enemyType, enemyData.stats);
        entity.addComponent(enemy);
        
        const sprite = new SpriteRenderer(24, 24, enemyData.color);
        entity.addComponent(sprite);
        
        entity.addTag('enemy');

        this.entities.add(entity);
        this.enemiesSpawned++;
        this.enemiesAlive++;

        // Also add to main game engine if available
        if (this.gameEngine) {
            this.gameEngine.entities.set(entity.id, entity);
            this.gameEngine.syncEntityWithSystems(entity);
        }

        console.log(`Spawned ${enemyType} enemy (${this.enemiesSpawned}/${this.enemiesInWave}) at (${this.spawnPosition.x}, ${this.spawnPosition.y})`);

        this.combatEvents.push({
            type: 'enemy_spawned',
            enemy: entity,
            enemyType: enemyType
        });

        return entity;
    }

    updateWaveStatus() {
        // Check if all enemies in wave are spawned and dead
        if (this.enemiesSpawned >= this.enemiesInWave && this.enemiesAlive <= 0) {
            this.completeWave();
        }
    }

    completeWave() {
        this.waveActive = false;
        this.waveComplete = true;
        // Don't increment currentWave here - it's already incremented in startWave()

        console.log(`Wave ${this.currentWave} completed!`);

        this.combatEvents.push({
            type: 'wave_completed',
            wave: this.currentWave,
            reward: this.waveReward
        });

        // Auto-advance to next wave after a delay
        if (this.currentWave < this.waves.length) {
            console.log(`Auto-advancing to wave ${this.currentWave + 1} in 3 seconds...`);
            setTimeout(() => {
                if (this.gameEngine) {
                    this.gameEngine.startWave();
                }
            }, 3000); // 3 second delay between waves
        } else {
            console.log('All waves completed!');
            this.combatEvents.push({
                type: 'all_waves_complete'
            });
        }
    }

    onEnemyDied(enemy) {
        this.enemiesAlive--;
        
        const enemyComp = enemy.getComponent('EnemyComponent');
        if (enemyComp) {
            this.combatEvents.push({
                type: 'enemy_died',
                enemy: enemy,
                reward: enemyComp.getReward()
            });
        }
    }

    updateEntity(entity, deltaTime) {
        const enemyComp = entity.getComponent('EnemyComponent');
        if (enemyComp) {
            enemyComp.update(deltaTime);
        }
    }

    getWaveInfo() {
        if (this.currentWave >= this.waves.length) {
            return {
                currentWave: this.currentWave,
                totalWaves: this.waves.length,
                waveComplete: true,
                description: 'All waves completed!'
            };
        }

        const wave = this.waves[this.currentWave];
        return {
            currentWave: this.currentWave + 1,
            totalWaves: this.waves.length,
            waveActive: this.waveActive,
            waveComplete: this.waveComplete,
            enemiesSpawned: this.enemiesSpawned,
            enemiesInWave: this.enemiesInWave,
            enemiesAlive: this.enemiesAlive,
            description: wave.description,
            reward: wave.reward
        };
    }

    getCombatEvents() {
        const events = [...this.combatEvents];
        this.combatEvents.length = 0;
        return events;
    }

    reset() {
        this.currentWave = 0;
        this.spawnTimer = 0;
        this.enemiesInWave = 0;
        this.enemiesSpawned = 0;
        this.enemiesAlive = 0;
        this.waveActive = false;
        this.waveComplete = false;
        this.waveReward = 0;
        this.combatEvents = [];
    }

    render(ctx) {
        // Render wave info
        const waveInfo = this.getWaveInfo();
        
        ctx.save();
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 18px Arial';
        ctx.textAlign = 'left';
        ctx.fillText(`Wave: ${waveInfo.currentWave}/${waveInfo.totalWaves}`, 20, 40);
        
        if (waveInfo.waveActive) {
            ctx.fillText(`Enemies: ${waveInfo.enemiesAlive}/${waveInfo.enemiesInWave}`, 20, 65);
        }
        
        ctx.restore();
    }
}
